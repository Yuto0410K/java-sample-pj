package com.example.javasamplepj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSamplePjApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSamplePjApplication.class, args);
	}
}
